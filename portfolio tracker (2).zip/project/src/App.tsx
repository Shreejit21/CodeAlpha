import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, PlusCircle, Trash2, Download, DollarSign, PieChart } from 'lucide-react';

interface Stock {
  id: string;
  symbol: string;
  name: string;
  quantity: number;
  purchasePrice: number;
}

interface StockPrice {
  [key: string]: {
    name: string;
    price: number;
  };
}

const STOCK_PRICES: StockPrice = {
  'AAPL': { name: 'Apple Inc.', price: 180.50 },
  'TSLA': { name: 'Tesla Inc.', price: 250.25 },
  'GOOGL': { name: 'Alphabet Inc.', price: 142.30 },
  'MSFT': { name: 'Microsoft Corp.', price: 375.80 },
  'AMZN': { name: 'Amazon.com Inc.', price: 145.90 },
  'NVDA': { name: 'NVIDIA Corp.', price: 465.75 },
  'META': { name: 'Meta Platforms Inc.', price: 325.40 },
  'NFLX': { name: 'Netflix Inc.', price: 455.20 },
  'AMD': { name: 'Advanced Micro Devices', price: 105.85 },
  'CRM': { name: 'Salesforce Inc.', price: 210.15 }
};

function App() {
  const [portfolio, setPortfolio] = useState<Stock[]>([]);
  const [selectedStock, setSelectedStock] = useState('');
  const [quantity, setQuantity] = useState<number>(1);

  const addStock = () => {
    if (!selectedStock || quantity <= 0) return;

    const stockData = STOCK_PRICES[selectedStock];
    if (!stockData) return;

    const newStock: Stock = {
      id: Date.now().toString(),
      symbol: selectedStock,
      name: stockData.name,
      quantity: quantity,
      purchasePrice: stockData.price
    };

    setPortfolio([...portfolio, newStock]);
    setSelectedStock('');
    setQuantity(1);
  };

  const removeStock = (id: string) => {
    setPortfolio(portfolio.filter(stock => stock.id !== id));
  };

  const calculatePortfolioStats = () => {
    const totalValue = portfolio.reduce((sum, stock) => {
      const currentPrice = STOCK_PRICES[stock.symbol]?.price || stock.purchasePrice;
      return sum + (currentPrice * stock.quantity);
    }, 0);

    const totalInvested = portfolio.reduce((sum, stock) => {
      return sum + (stock.purchasePrice * stock.quantity);
    }, 0);

    const totalGainLoss = totalValue - totalInvested;
    const gainLossPercentage = totalInvested > 0 ? (totalGainLoss / totalInvested) * 100 : 0;

    return {
      totalValue,
      totalInvested,
      totalGainLoss,
      gainLossPercentage
    };
  };

  const exportToCSV = () => {
    const stats = calculatePortfolioStats();
    let csvContent = 'Stock Symbol,Company Name,Quantity,Purchase Price,Current Price,Current Value,Gain/Loss\n';
    
    portfolio.forEach(stock => {
      const currentPrice = STOCK_PRICES[stock.symbol]?.price || stock.purchasePrice;
      const currentValue = currentPrice * stock.quantity;
      const gainLoss = currentValue - (stock.purchasePrice * stock.quantity);
      
      csvContent += `${stock.symbol},${stock.name},${stock.quantity},$${stock.purchasePrice.toFixed(2)},$${currentPrice.toFixed(2)},$${currentValue.toFixed(2)},$${gainLoss.toFixed(2)}\n`;
    });

    csvContent += `\nPortfolio Summary\n`;
    csvContent += `Total Investment,$${stats.totalInvested.toFixed(2)}\n`;
    csvContent += `Current Value,$${stats.totalValue.toFixed(2)}\n`;
    csvContent += `Total Gain/Loss,$${stats.totalGainLoss.toFixed(2)}\n`;
    csvContent += `Gain/Loss Percentage,${stats.gainLossPercentage.toFixed(2)}%\n`;

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `portfolio_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const stats = calculatePortfolioStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-lg">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">Portfolio Tracker</h1>
                <p className="text-purple-200">Track your stock investments with real-time calculations</p>
              </div>
            </div>
            {portfolio.length > 0 && (
              <button
                onClick={exportToCSV}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors duration-200"
              >
                <Download className="h-4 w-4" />
                <span>Export CSV</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Add Stock Section */}
        <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6 mb-8">
          <h2 className="text-2xl font-semibold text-white mb-6 flex items-center">
            <PlusCircle className="h-6 w-6 mr-2 text-blue-400" />
            Add Stock to Portfolio
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-purple-200 mb-2">
                Stock Symbol
              </label>
              <select
                value={selectedStock}
                onChange={(e) => setSelectedStock(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="" className="bg-slate-800">Select a stock</option>
                {Object.entries(STOCK_PRICES).map(([symbol, data]) => (
                  <option key={symbol} value={symbol} className="bg-slate-800">
                    {symbol} - {data.name} (${data.price.toFixed(2)})
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-purple-200 mb-2">
                Quantity
              </label>
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div className="flex items-end">
              <button
                onClick={addStock}
                disabled={!selectedStock || quantity <= 0}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <PlusCircle className="h-4 w-4" />
                <span>Add Stock</span>
              </button>
            </div>
          </div>
        </div>

        {/* Portfolio Summary */}
        {portfolio.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm">Total Investment</p>
                  <p className="text-2xl font-bold">${stats.totalInvested.toFixed(2)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-blue-200" />
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-purple-600 to-purple-700 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm">Current Value</p>
                  <p className="text-2xl font-bold">${stats.totalValue.toFixed(2)}</p>
                </div>
                <PieChart className="h-8 w-8 text-purple-200" />
              </div>
            </div>
            
            <div className={`rounded-xl p-6 text-white ${
              stats.totalGainLoss >= 0 
                ? 'bg-gradient-to-r from-green-600 to-green-700' 
                : 'bg-gradient-to-r from-red-600 to-red-700'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${stats.totalGainLoss >= 0 ? 'text-green-100' : 'text-red-100'}`}>
                    Total Gain/Loss
                  </p>
                  <p className="text-2xl font-bold">
                    ${Math.abs(stats.totalGainLoss).toFixed(2)}
                  </p>
                </div>
                {stats.totalGainLoss >= 0 ? (
                  <TrendingUp className="h-8 w-8 text-green-200" />
                ) : (
                  <TrendingDown className="h-8 w-8 text-red-200" />
                )}
              </div>
            </div>
            
            <div className={`rounded-xl p-6 text-white ${
              stats.gainLossPercentage >= 0 
                ? 'bg-gradient-to-r from-emerald-600 to-emerald-700' 
                : 'bg-gradient-to-r from-rose-600 to-rose-700'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${stats.gainLossPercentage >= 0 ? 'text-emerald-100' : 'text-rose-100'}`}>
                    Percentage
                  </p>
                  <p className="text-2xl font-bold">
                    {stats.gainLossPercentage >= 0 ? '+' : ''}{stats.gainLossPercentage.toFixed(2)}%
                  </p>
                </div>
                {stats.gainLossPercentage >= 0 ? (
                  <TrendingUp className="h-8 w-8 text-emerald-200" />
                ) : (
                  <TrendingDown className="h-8 w-8 text-rose-200" />
                )}
              </div>
            </div>
          </div>
        )}

        {/* Portfolio Holdings */}
        {portfolio.length > 0 ? (
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6">
            <h2 className="text-2xl font-semibold text-white mb-6">Your Portfolio</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {portfolio.map((stock) => {
                const currentPrice = STOCK_PRICES[stock.symbol]?.price || stock.purchasePrice;
                const currentValue = currentPrice * stock.quantity;
                const gainLoss = currentValue - (stock.purchasePrice * stock.quantity);
                const gainLossPercentage = ((currentPrice - stock.purchasePrice) / stock.purchasePrice) * 100;

                return (
                  <div
                    key={stock.id}
                    className="bg-white/5 border border-white/10 rounded-lg p-4 hover:bg-white/10 transition-all duration-200 hover:scale-105"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-white">{stock.symbol}</h3>
                        <p className="text-purple-200 text-sm">{stock.name}</p>
                      </div>
                      <button
                        onClick={() => removeStock(stock.id)}
                        className="text-red-400 hover:text-red-300 transition-colors duration-200"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Quantity:</span>
                        <span className="text-white font-medium">{stock.quantity} shares</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Purchase Price:</span>
                        <span className="text-white font-medium">${stock.purchasePrice.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Current Price:</span>
                        <span className="text-white font-medium">${currentPrice.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Current Value:</span>
                        <span className="text-white font-bold">${currentValue.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-purple-200">Gain/Loss:</span>
                        <span className={`font-bold ${gainLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {gainLoss >= 0 ? '+' : ''}${gainLoss.toFixed(2)} ({gainLossPercentage >= 0 ? '+' : ''}{gainLossPercentage.toFixed(2)}%)
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-12 text-center">
            <PieChart className="h-16 w-16 text-purple-400 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-white mb-2">No Stocks in Portfolio</h3>
            <p className="text-purple-200 mb-6">Add your first stock to start tracking your investments</p>
            <div className="text-sm text-purple-300">
              <p>Available stocks: {Object.keys(STOCK_PRICES).join(', ')}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;